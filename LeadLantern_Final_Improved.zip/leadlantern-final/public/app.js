const STAGES=["New Inquiry","Contacted","Proposal Sent","Won","Lost"];
let leads=[], services=[], filter="All", searchTerm="", editingId=null, draggedId=null;
const $=s=>document.querySelector(s);
const money=n=>"₹"+Math.round(Number(n)||0).toLocaleString("en-IN");
const today=()=>new Date().toISOString().slice(0,10);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeHTML=s=>window.DOMPurify?DOMPurify.sanitize(s):esc(s);
async function api(url,options={}) {
  const response=await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  if(!response.ok){let data={};try{data=await response.json()}catch{}throw new Error(data.error||`Request failed (${response.status})`);}
  return response.status===204?null:response.json();
}
function toast(message){const el=$("#toast");el.textContent=message;el.style.display="block";setTimeout(()=>el.style.display="none",2800);}
function score(l){const svc=services.find(s=>s.name.toLowerCase()===String(l.service).toLowerCase()),rate=svc?Number(svc.rate):0;
 const u=({Emergency:40,Immediate:36,"Within 1 Week":24,Planning:10})[l.urgency]||0;
 const b=Math.round(30*Math.min(1,(.8*(+l.budget||0)+.2*rate)/5000));
 const c=(l.name?5:0)+(l.phone?8:0)+(l.email?7:0),r=l.returning?10:0,t=Math.min(100,u+b+c+r);
 return {total:t,tier:t>=70?"Hot":t>=40?"Warm":"Cold"};}
const active=l=>!["Won","Lost"].includes(l.stage);
function due(l){return !l.followup||!active(l)?"":l.followup<today()?"over":l.followup===today()?"today":"";}
function stats(){const a=leads.filter(active),w=leads.filter(l=>l.stage==="Won"),closed=leads.filter(l=>["Won","Lost"].includes(l.stage));
 return {active:a,won:w,value:a.reduce((s,l)=>s+(+l.budget||0),0),rate:closed.length?Math.round(w.length/closed.length*100):0,avg:w.length?Math.round(w.reduce((s,l)=>s+(+l.budget||0),0)/w.length):0,over:a.filter(l=>due(l)==="over"),today:a.filter(l=>due(l)==="today")};}
function metricHTML(){const s=stats();return [["Active pipeline value",money(s.value)],["Active leads",s.active.length],["Conversion rate",s.rate+"%"],["Average won deal",money(s.avg)]].map(([a,b])=>`<div class="metric"><span>${a}</span><b>${b}</b></div>`).join("");}
async function refresh(){const [l,s]=await Promise.all([api("/api/leads"),api("/api/services")]);leads=l.data;services=s.data;render();}
function render(){const m=metricHTML();$("#homeMetrics").innerHTML=m;$("#pipelineMetrics").innerHTML=m;$("#analyticsMetrics").innerHTML=m;
 const st=stats();$("#alerts").innerHTML=st.over.length+st.today.length?`<p class="alert">🔔 ${st.over.length} overdue and ${st.today.length} due-today follow-up(s) need attention.</p>`:"";
 $("#filters").innerHTML=["All","Hot","Warm","Cold"].map(x=>`<button class="chip ${filter===x?"active":""}" data-filter="${x}">${x}</button>`).join("");
 const visible=leads.filter(l=>(filter==="All"||score(l).tier===filter)&&(!searchTerm||[l.name,l.phone,l.service].join(" ").toLowerCase().includes(searchTerm)));
 $("#board").innerHTML=STAGES.map((stage,i)=>{const list=visible.filter(l=>l.stage===stage).sort((a,b)=>score(b).total-score(a).total);
 return `<section class="column" data-stage="${stage}"><h3>${stage}<small>${list.length} · ${money(list.reduce((n,l)=>n+(+l.budget||0),0))}</small></h3>${list.map(cardHTML).join("")||'<small class="muted">No leads in this stage</small>'}</section>`;}).join("");
 drawAnalytics();drawCatalog();populateServices();}
function cardHTML(l){const s=score(l),d=due(l);return `<article class="lead-card" draggable="true" data-id="${l.id}"><div class="card-top"><div><b data-open="${l.id}">${esc(l.name)}</b><br><small>${esc(l.service)}</small></div><div class="score">${s.total}</div></div><div class="card-bottom"><b>${money(l.budget)}</b><span><span class="tag ${s.tier}">${s.tier}</span> ${d?`<small>${d==="over"?"Overdue":"Today"}</small>`:""}</span></div><small>${esc(l.urgency)}</small><div class="card-actions"><select aria-label="Move ${esc(l.name)}" data-stage-select="${l.id}">${STAGES.map(x=>`<option ${x===l.stage?"selected":""}>${x}</option>`).join("")}</select><button class="btn" data-whatsapp="${l.id}" title="WhatsApp follow-up">💬</button></div></article>`;}
function bars(rows,format){const max=Math.max(1,...rows.map(x=>x[1]));return rows.length?rows.map(([name,value])=>`<div class="chart-row"><span>${esc(name)}</span><div class="bar"><i style="width:${value/max*100}%"></i></div><em>${format(value)}</em></div>`).join(""):'<p class="muted">No data available yet.</p>';}
function drawAnalytics(){const a=leads.filter(active),count=t=>a.filter(l=>score(l).tier===t).length;
 $("#funnel").innerHTML=bars(STAGES.map(s=>[s,leads.filter(l=>l.stage===s).length]),n=>n+" leads");
 $("#tiers").innerHTML=bars([["Hot",count("Hot")],["Warm",count("Warm")],["Cold",count("Cold")]],n=>n+" leads");
 const by={};leads.filter(l=>l.stage!=="Lost").forEach(l=>by[l.service]=(by[l.service]||0)+(+l.budget||0));
 $("#serviceValues").innerHTML=bars(Object.entries(by).sort((a,b)=>b[1]-a[1]).slice(0,8),money);
 const q=a.filter(l=>due(l)).sort((x,y)=>x.followup.localeCompare(y.followup));
 $("#followups").innerHTML=q.map(l=>`<div class="follow-row"><span><b>${esc(l.name)}</b><br><small>${esc(l.service)} · ${l.followup}</small></span><button class="btn" data-open="${l.id}">View</button></div>`).join("")||'<p class="muted">🎉 No follow-ups due.</p>';}
function populateServices(){$("#serviceOptions").innerHTML=services.map(s=>`<option value="${esc(s.name)}"></option>`).join("");}
function drawCatalog(){$("#catalog").innerHTML=services.map(s=>`<div class="service-row"><input aria-label="Service name" data-service-name="${s.id}" value="${esc(s.name)}"><input aria-label="Rate" type="number" min="0" data-service-rate="${s.id}" value="${s.rate}"><button class="btn danger" data-service-delete="${s.id}">Delete</button></div>`).join("")||'<p class="muted">No services yet.</p>';}
function openLead(id=null){editingId=id;const form=$("#leadForm");form.reset();form.elements.budget.value=0;$("#dialogTitle").textContent=id?"Edit lead":"New lead";
 if(id){const l=leads.find(x=>x.id===id);Object.entries(l).forEach(([k,v])=>{if(form.elements[k])form.elements[k].value=v??""});form.elements.returning.checked=l.returning;form.elements.notesText.value="";}
 $("#leadDialog").showModal();previewScore();}
function previewScore(){const f=$("#leadForm"),v=Object.fromEntries(new FormData(f));const s=score({...v,returning:f.elements.returning.checked});$("#scorePreview").textContent=`Estimated score: ${s.total}/100 — ${s.tier} lead`;}
async function saveLead(e){e.preventDefault();const f=$("#leadForm"),v=Object.fromEntries(new FormData(f));v.returning=f.elements.returning.checked;v.budget=Number(v.budget||0);
 if(editingId){const old=leads.find(l=>l.id===editingId);v.stage=old.stage;v.notes=old.notes||[];if(v.notesText?.trim())v.notes.push({text:v.notesText.trim(),date:new Date().toLocaleString()});delete v.notesText;await api(`/api/leads/${editingId}`,{method:"PUT",body:JSON.stringify(v)});}
 else{v.stage="New Inquiry";v.notes=[{text:"Lead captured via intake form.",date:new Date().toLocaleString()}];if(v.notesText?.trim())v.notes.push({text:v.notesText.trim(),date:new Date().toLocaleString()});delete v.notesText;await api("/api/leads",{method:"POST",body:JSON.stringify(v)});}
 $("#leadDialog").close();await refresh();toast("Lead saved successfully.");}
async function changeStage(id,stage){const l=leads.find(x=>x.id===Number(id));if(!l)return;const updated={...l,stage,notes:[...(l.notes||[]),{text:`Moved from ${l.stage} to ${stage}.`,date:new Date().toLocaleString()}]};await api(`/api/leads/${id}`,{method:"PUT",body:JSON.stringify(updated)});await refresh();}
function whatsapp(id){const l=leads.find(x=>x.id===Number(id));if(!l)return;let phone=l.phone.replace(/\D/g,"");if(phone.length===10)phone="91"+phone;const message=`Hi ${l.name}, following up on your ${l.service} enquiry. Can we confirm a time that works for you?`;window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`,"_blank","noopener");}
function detail(id){const l=leads.find(x=>x.id===Number(id));if(!l)return;const s=score(l);const dlg=$("#detailDialog");dlg.innerHTML=safeHTML(`<div class="card-top"><div><h2>${esc(l.name)}</h2><small>${esc(l.service)} · ${money(l.budget)} · ${esc(l.urgency)}</small></div><div class="score">${s.total}</div></div><p>☎ ${esc(l.phone)} · ${esc(l.email||"No email")} · <span class="tag ${s.tier}">${s.tier}</span></p><div class="form-grid"><label>Follow-up date<input id="detailFollowup" type="date" value="${esc(l.followup||"")}"></label><label>Stage<select id="detailStage">${STAGES.map(x=>`<option ${x===l.stage?"selected":""}>${x}</option>`).join("")}</select></label></div><h3>Activity history</h3><div class="activity">${(l.notes||[]).slice().reverse().map(n=>`<p><small>${esc(n.date)}</small>${esc(n.text)}</p>`).join("")||"No activity recorded."}</div><textarea id="detailNote" maxlength="1000" placeholder="Add a call, quote or follow-up note…"></textarea><div class="button-row"><button class="btn" id="detailEdit">Edit</button><button class="btn" id="detailWhatsApp">WhatsApp</button><button class="btn" id="detailDelete">Delete</button><button class="btn pri" id="detailSave">Save changes</button></div>`);dlg.showModal();
 $("#detailEdit").onclick=()=>{dlg.close();openLead(l.id);};$("#detailWhatsApp").onclick=()=>whatsapp(l.id);
 $("#detailDelete").onclick=async()=>{if(confirm("Delete this lead permanently?")){await api(`/api/leads/${l.id}`,{method:"DELETE"});dlg.close();await refresh();toast("Lead deleted.");}};
 $("#detailSave").onclick=async()=>{const note=$("#detailNote").value.trim(),notes=[...(l.notes||[])];if(note)notes.push({text:note,date:new Date().toLocaleString()});const updated={...l,followup:$("#detailFollowup").value,stage:$("#detailStage").value,notes};await api(`/api/leads/${l.id}`,{method:"PUT",body:JSON.stringify(updated)});dlg.close();await refresh();toast("Lead updated.");};}
async function importCSV(){const text=$("#csvText").value;if(!text.trim()){toast("Paste CSV data or choose a file first.");return;}try{const response=await fetch("/api/csv/import",{method:"POST",headers:{"Content-Type":"text/csv"},body:text});const data=await response.json();if(!response.ok)throw new Error(data.error);$("#csvMessage").textContent=`Imported ${data.imported} row(s); rejected ${data.rejected.length}.`;await refresh();}catch(e){$("#csvMessage").textContent=e.message;}}
async function init(){try{await api("/api/health");$("#apiStatus").textContent="● API connected";$("#apiStatus").style.color="var(--ok)";await refresh();}catch(e){$("#apiStatus").textContent="API unavailable";toast("Could not connect to the server. Please restart the application.");}}
function route(){let page=location.hash.slice(1);if(!["home","pipeline","analytics","tools"].includes(page))page="home";document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id==="p-"+page));document.querySelectorAll(".links a").forEach(x=>x.classList.toggle("active",x.getAttribute("href")==="#"+page));if(page==="pipeline")render();if(page==="analytics")drawAnalytics();if(page==="tools")drawCatalog();window.scrollTo(0,0);}
document.addEventListener("click",async e=>{const t=e.target.closest("button");if(!t)return;try{
 if(t.dataset.filter){filter=t.dataset.filter;render();}
 if(t.dataset.open)detail(t.dataset.open);
 if(t.dataset.whatsapp)whatsapp(t.dataset.whatsapp);
 if(t.id==="addLead")openLead();
 if(t.id==="cancelDialog")$("#leadDialog").close();
 if(t.id==="addService"){const name=prompt("Service name:");if(!name)return;const rate=Number(prompt("Standard rate (₹):","500"));await api("/api/services",{method:"POST",body:JSON.stringify({name,rate})});await refresh();}
 if(t.dataset.serviceDelete){if(confirm("Delete this service?")){await api(`/api/services/${t.dataset.serviceDelete}`,{method:"DELETE"});await refresh();}}
 if(t.id==="exportCsv"){const r=await fetch("/api/csv/export");const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="LeadLantern_Leads.csv";a.click();URL.revokeObjectURL(url);}
 if(t.id==="importCsv")await importCSV();
 if(t.id==="deleteAll"&&confirm("Delete every lead? This cannot be undone.")){await api("/api/leads",{method:"DELETE"});await refresh();toast("All leads deleted.");}
 }catch(err){toast(err.message);}});
document.addEventListener("change",async e=>{const t=e.target;try{if(t.dataset.stageSelect)await changeStage(t.dataset.stageSelect,t.value);
 if(t.dataset.serviceName||t.dataset.serviceRate){const id=t.dataset.serviceName||t.dataset.serviceRate,s=services.find(x=>x.id===Number(id));const name=document.querySelector(`[data-service-name="${id}"]`).value,rate=Number(document.querySelector(`[data-service-rate="${id}"]`).value);await api(`/api/services/${id}`,{method:"PUT",body:JSON.stringify({name,rate})});await refresh();}
 }catch(err){toast(err.message);await refresh();}});
$("#search").addEventListener("input",e=>{searchTerm=e.target.value.toLowerCase();render();});
$("#leadForm").addEventListener("submit",e=>saveLead(e).catch(err=>toast(err.message)));
$("#leadForm").addEventListener("input",previewScore);
$("#csvFile").addEventListener("change",async e=>{const f=e.target.files[0];if(f)$("#csvText").value=await f.text();});
$("#board").addEventListener("dragstart",e=>{const card=e.target.closest(".lead-card");if(card){draggedId=card.dataset.id;card.classList.add("dragging");}});
$("#board").addEventListener("dragend",()=>{draggedId=null;document.querySelectorAll(".dragging").forEach(x=>x.classList.remove("dragging"));});
$("#board").addEventListener("dragover",e=>{if(e.target.closest(".column"))e.preventDefault();});
$("#board").addEventListener("drop",e=>{const col=e.target.closest(".column");if(col&&draggedId){e.preventDefault();changeStage(draggedId,col.dataset.stage).catch(err=>toast(err.message));draggedId=null;}});
$("#detailDialog").addEventListener("click",e=>{if(e.target===e.currentTarget)e.currentTarget.close();});
window.addEventListener("hashchange",route);route();init();