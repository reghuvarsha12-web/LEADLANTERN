const app = require("./src/app");
const { initializeDatabase } = require("./src/db");

const PORT = Number(process.env.PORT) || 3000;
initializeDatabase();

if (require.main === module) {
  app.listen(PORT, () => console.log(`LeadLantern running at http://localhost:${PORT}`));
}
module.exports = app;