const { z } = require("zod");
const stages = ["New Inquiry","Contacted","Proposal Sent","Won","Lost"];
const urgencies = ["Emergency","Immediate","Within 1 Week","Planning"];
const leadSchema = z.object({
  name: z.string().trim().min(1).max(100),
  phone: z.string().trim().min(7).max(20).regex(/^[+0-9() .-]+$/),
  email: z.string().trim().max(150).email().or(z.literal("")).optional().default(""),
  service: z.string().trim().min(1).max(100),
  budget: z.coerce.number().min(0).max(100000000).default(0),
  urgency: z.enum(urgencies).default("Planning"),
  stage: z.enum(stages).default("New Inquiry"),
  returning: z.coerce.boolean().default(false),
  followup: z.string().max(10).regex(/^$|^\\d{4}-\\d{2}-\\d{2}$/).default(""),
  notes: z.array(z.object({ text: z.string().max(1000), date: z.string().max(60) })).max(200).default([])
});
function validateLead(req, res, next) {
  const result = leadSchema.safeParse(req.body);
  if (!result.success) return res.status(400).json({ error: "Validation failed", details: result.error.issues.map(i => ({ field: i.path.join("."), message: i.message })) });
  req.validatedBody = result.data;
  next();
}
module.exports = { validateLead };