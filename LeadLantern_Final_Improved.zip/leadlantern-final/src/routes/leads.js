const express = require("express");
const router = express.Router();
const repo = require("../repositories/leadRepository");
const services = require("../repositories/serviceRepository");
const { validateLead } = require("../middleware/validate");
const { calculateScore } = require("../services/leadService");

router.get("/", (req,res) => {
  const items = repo.all().map(l => ({ ...l, score: calculateScore(l, services.all()) }));
  res.json({ data: items });
});
router.get("/:id", (req,res) => {
  const lead = repo.find(Number(req.params.id));
  if (!lead) return res.status(404).json({ error: "Lead not found" });
  res.json({ data: { ...lead, score: calculateScore(lead, services.all()) } });
});
router.post("/", validateLead, (req,res) => res.status(201).json({ data: repo.create(req.validatedBody) }));
router.put("/:id", validateLead, (req,res) => {
  const lead = repo.update(Number(req.params.id), req.validatedBody);
  if (!lead) return res.status(404).json({ error: "Lead not found" });
  res.json({ data: lead });
});
router.delete("/:id", (req,res) => repo.remove(Number(req.params.id)) ? res.status(204).end() : res.status(404).json({ error: "Lead not found" }));
router.delete("/", (req,res) => { repo.removeAll(); res.status(204).end(); });
module.exports = router;