const express = require("express");
const { z } = require("zod");
const repo = require("../repositories/serviceRepository");
const router = express.Router();
const schema = z.object({ name: z.string().trim().min(1).max(100), rate: z.coerce.number().min(0).max(100000000) });
router.get("/", (req,res) => res.json({ data: repo.all() }));
router.post("/", (req,res) => {
  const v = schema.safeParse(req.body);
  if (!v.success) return res.status(400).json({ error: "A valid service name and non-negative rate are required." });
  try { res.status(201).json({ data: repo.create(v.data.name, v.data.rate) }); }
  catch { res.status(409).json({ error: "A service with that name already exists." }); }
});
router.put("/:id", (req,res) => {
  const v = schema.safeParse(req.body);
  if (!v.success) return res.status(400).json({ error: "Invalid service details." });
  try {
    const item = repo.update(Number(req.params.id), v.data.name, v.data.rate);
    return item ? res.json({ data: item }) : res.status(404).json({ error: "Service not found." });
  } catch { return res.status(409).json({ error: "A service with that name already exists." }); }
});
router.delete("/:id", (req,res) => repo.remove(Number(req.params.id)) ? res.status(204).end() : res.status(404).json({ error: "Service not found." }));
module.exports = router;