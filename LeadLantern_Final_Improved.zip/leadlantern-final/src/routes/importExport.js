const express = require("express");
const { parse } = require("csv-parse/sync");
const repo = require("../repositories/leadRepository");
const { validateLead } = require("../middleware/validate");
const router = express.Router();
const HEADERS = ["name","phone","email","service","budget","urgency","stage","returning","followup"];

function safeCell(value) {
  const s = String(value ?? "");
  return /^[=+@\\-\\t\\r]/.test(s) ? "'" + s : s;
}
router.get("/export", (req,res) => {
  const rows = repo.all();
  const quote = v => '"' + safeCell(v).replace(/"/g,'""') + '"';
  const csv = [HEADERS.join(","), ...rows.map(l => HEADERS.map(h => quote(h === "returning" ? (l.returning ? "yes" : "no") : l[h])).join(","))].join("\\r\\n");
  res.type("text/csv").attachment("LeadLantern_Leads.csv").send(csv);
});
router.post("/import", express.text({ type: ["text/csv","text/plain"], limit: "1mb" }), (req,res) => {
  try {
    const records = parse(req.body || "", { columns: true, skip_empty_lines: true, trim: true, bom: true, relax_column_count: false });
    if (!records.length) return res.status(400).json({ error: "The CSV contains no data rows." });
    if (records.length > 1000) return res.status(400).json({ error: "Import is limited to 1,000 rows at a time." });
    const imported = [];
    const rejected = [];
    records.forEach((r, index) => {
      const input = {
        name: r.name, phone: r.phone, email: r.email || "", service: r.service,
        budget: r.budget || 0, urgency: r.urgency || "Planning",
        stage: r.stage || "New Inquiry", returning: String(r.returning).toLowerCase() === "yes" || String(r.returning) === "true",
        followup: r.followup || "", notes: [{ text: "Imported from CSV.", date: new Date().toISOString() }]
      };
      const { z } = require("zod");
      const schema = z.object({
        name:z.string().trim().min(1).max(100), phone:z.string().trim().min(7).max(20).regex(/^[+0-9() .-]+$/),
        email:z.string().trim().max(150).email().or(z.literal("")), service:z.string().trim().min(1).max(100),
        budget:z.coerce.number().min(0).max(100000000), urgency:z.enum(["Emergency","Immediate","Within 1 Week","Planning"]),
        stage:z.enum(["New Inquiry","Contacted","Proposal Sent","Won","Lost"]), returning:z.boolean(),
        followup:z.string().max(10).regex(/^$|^\\d{4}-\\d{2}-\\d{2}$/), notes:z.array(z.any())
      });
      const parsed = schema.safeParse(input);
      if (!parsed.success) rejected.push({ row: index + 2, reason: "Missing or invalid required values." });
      else imported.push(repo.create(parsed.data));
    });
    res.json({ imported: imported.length, rejected });
  } catch (error) {
    res.status(400).json({ error: "CSV could not be parsed. Check its headers, quotes and column counts." });
  }
});
module.exports = router;