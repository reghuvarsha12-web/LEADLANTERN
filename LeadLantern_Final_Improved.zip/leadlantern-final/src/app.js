const express = require("express");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const leads = require("./routes/leads");
const services = require("./routes/services");
const importExport = require("./routes/importExport");

const app = express();
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(express.json({ limit: "100kb" }));
app.use("/api/leads", leads);
app.use("/api/services", services);
app.use("/api/csv", importExport);
app.get("/api/health", (req,res) => res.json({ status: "ok", service: "LeadLantern API", timestamp: new Date().toISOString() }));
app.use(express.static(path.join(__dirname, "..", "public")));
app.use((req,res) => res.status(404).json({ error: "Route not found" }));
app.use((err,req,res,next) => {
  console.error(err.message);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: "The server could not complete the request. Please try again." });
});
module.exports = app;