const STAGES = ["New Inquiry", "Contacted", "Proposal Sent", "Won", "Lost"];
const URGENCY = { Emergency: 40, Immediate: 36, "Within 1 Week": 24, Planning: 10 };

function calculateScore(lead, services = []) {
  const service = services.find(s => s.name.toLowerCase() === String(lead.service || "").toLowerCase());
  const rate = service ? Number(service.rate) : 0;
  const urgency = URGENCY[lead.urgency] || 0;
  const budget = Math.round(30 * Math.min(1, (0.8 * Number(lead.budget || 0) + 0.2 * rate) / 5000));
  const contact = (lead.name ? 5 : 0) + (lead.phone ? 8 : 0) + (lead.email ? 7 : 0);
  const returning = lead.returning ? 10 : 0;
  const total = Math.min(100, urgency + budget + contact + returning);
  return { total, urgency, budget, contact, returning,
    tier: total >= 70 ? "Hot" : total >= 40 ? "Warm" : "Cold" };
}
function normalizeLead(row) {
  return {
    name: String(row.name || "").trim(),
    phone: String(row.phone || "").trim(),
    email: String(row.email || "").trim(),
    service: String(row.service || "").trim(),
    budget: Number(row.budget || 0),
    urgency: URGENCY[row.urgency] ? row.urgency : "Planning",
    stage: STAGES.includes(row.stage) ? row.stage : STAGES[0],
    returning: Boolean(row.returning),
    followup: row.followup || "",
    notes: Array.isArray(row.notes) ? row.notes : []
  };
}
module.exports = { calculateScore, normalizeLead, STAGES, URGENCY };