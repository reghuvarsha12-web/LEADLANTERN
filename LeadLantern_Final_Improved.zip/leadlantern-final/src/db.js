const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "leadlantern.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS leads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT DEFAULT '',
      service TEXT NOT NULL,
      budget REAL NOT NULL DEFAULT 0,
      urgency TEXT NOT NULL DEFAULT 'Planning',
      stage TEXT NOT NULL DEFAULT 'New Inquiry',
      returning INTEGER NOT NULL DEFAULT 0,
      followup TEXT DEFAULT '',
      notes TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE COLLATE NOCASE,
      rate REAL NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_leads_stage ON leads(stage);
    CREATE INDEX IF NOT EXISTS idx_leads_followup ON leads(followup);
  `);
  const count = db.prepare("SELECT COUNT(*) AS n FROM services").get().n;
  if (!count) {
    const insert = db.prepare("INSERT INTO services(name, rate) VALUES(?, ?)");
    [["HVAC Repair",450],["Interior Painting",1800],["Commercial Plumbing",1200],
     ["Legal Consult",300],["Electrical Rewiring",900],["Roof Repair",2500],
     ["Coaching Package",600],["Website Design",2000]].forEach(x => insert.run(...x));
  }
}
module.exports = { db, initializeDatabase };