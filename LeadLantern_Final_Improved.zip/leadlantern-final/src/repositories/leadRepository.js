const { db } = require("../db");
const { normalizeLead } = require("../services/leadService");

function parse(row) {
  if (!row) return null;
  return { ...row, returning: Boolean(row.returning), notes: JSON.parse(row.notes || "[]") };
}
function all() { return db.prepare("SELECT * FROM leads ORDER BY id DESC").all().map(parse); }
function find(id) { return parse(db.prepare("SELECT * FROM leads WHERE id = ?").get(id)); }
function create(input) {
  const l = normalizeLead(input);
  const result = db.prepare(`INSERT INTO leads(name,phone,email,service,budget,urgency,stage,returning,followup,notes)
    VALUES(@name,@phone,@email,@service,@budget,@urgency,@stage,@returning,@followup,@notes)`)
    .run({ ...l, returning: l.returning ? 1 : 0, notes: JSON.stringify(l.notes) });
  return find(result.lastInsertRowid);
}
function update(id, input) {
  const current = find(id);
  if (!current) return null;
  const l = normalizeLead({ ...current, ...input });
  db.prepare(`UPDATE leads SET name=@name,phone=@phone,email=@email,service=@service,budget=@budget,
    urgency=@urgency,stage=@stage,returning=@returning,followup=@followup,notes=@notes,
    updated_at=CURRENT_TIMESTAMP WHERE id=@id`)
    .run({ ...l, id, returning: l.returning ? 1 : 0, notes: JSON.stringify(l.notes) });
  return find(id);
}
function remove(id) { return db.prepare("DELETE FROM leads WHERE id = ?").run(id).changes > 0; }
function removeAll() { db.prepare("DELETE FROM leads").run(); }
module.exports = { all, find, create, update, remove, removeAll };