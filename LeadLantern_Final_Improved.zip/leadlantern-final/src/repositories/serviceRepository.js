const { db } = require("../db");
function all() { return db.prepare("SELECT * FROM services ORDER BY name").all(); }
function create(name, rate) {
  const result = db.prepare("INSERT INTO services(name,rate) VALUES(?,?)").run(name.trim(), rate);
  return db.prepare("SELECT * FROM services WHERE id=?").get(result.lastInsertRowid);
}
function update(id, name, rate) {
  const result = db.prepare("UPDATE services SET name=?, rate=? WHERE id=?").run(name.trim(), rate, id);
  return result.changes ? db.prepare("SELECT * FROM services WHERE id=?").get(id) : null;
}
function remove(id) { return db.prepare("DELETE FROM services WHERE id=?").run(id).changes > 0; }
module.exports = { all, create, update, remove };