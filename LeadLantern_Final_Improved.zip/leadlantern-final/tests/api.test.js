const request = require("supertest");
const app = require("../src/app");
const { initializeDatabase, db } = require("../src/db");
beforeAll(() => initializeDatabase());
beforeEach(() => db.prepare("DELETE FROM leads").run());
describe("LeadLantern REST API", () => {
  test("health endpoint confirms API availability", async () => {
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
  });
  test("creates and retrieves a valid lead", async () => {
    const payload = { name:"Test Customer",phone:"9876543210",email:"test@example.com",service:"HVAC Repair",budget:1200,urgency:"Immediate",stage:"New Inquiry",returning:false,followup:"",notes:[] };
    const created = await request(app).post("/api/leads").send(payload);
    expect(created.status).toBe(201);
    const list = await request(app).get("/api/leads");
    expect(list.body.data.some(x=>x.name==="Test Customer")).toBe(true);
  });
  test("rejects invalid phone input", async () => {
    const res = await request(app).post("/api/leads").send({ name:"Bad",phone:"x",service:"Repair",budget:0 });
    expect(res.status).toBe(400);
  });
});