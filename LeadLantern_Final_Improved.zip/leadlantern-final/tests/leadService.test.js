const { calculateScore, normalizeLead } = require("../src/services/leadService");
const services = [{ name: "HVAC Repair", rate: 450 }];
describe("Lead scoring", () => {
  test("returns a bounded score and Hot tier for a high-priority lead", () => {
    const result = calculateScore({ name:"A",phone:"1234567890",email:"a@b.com",service:"HVAC Repair",budget:5000,urgency:"Emergency",returning:true }, services);
    expect(result.total).toBeLessThanOrEqual(100);
    expect(result.tier).toBe("Hot");
  });
  test("classifies a low-priority lead as Cold", () => {
    const result = calculateScore({ name:"A",phone:"",email:"",service:"Unknown",budget:0,urgency:"Planning",returning:false }, []);
    expect(result.tier).toBe("Cold");
  });
  test("normalizes unsupported stage and urgency safely", () => {
    const result = normalizeLead({ name:"Test",phone:"1234567",service:"Other",stage:"Injected",urgency:"Unknown" });
    expect(result.stage).toBe("New Inquiry");
    expect(result.urgency).toBe("Planning");
  });
});