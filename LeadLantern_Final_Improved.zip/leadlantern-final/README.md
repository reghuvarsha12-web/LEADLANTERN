# LeadLantern — Final improved version

LeadLantern is a lightweight CRM for local service businesses. This version preserves the original product experience while adding a server-backed, three-tier architecture.

## Technology stack
- **Presentation tier:** HTML5, CSS3 and browser JavaScript in `public/`
- **Application tier:** Node.js + Express REST API in `src/routes/` and `src/services/`
- **Data tier:** SQLite database using `better-sqlite3` in `src/repositories/`
- **Validation/security:** Zod validation, Helmet security headers, request rate limiting, bounded request sizes, safe text rendering and CSV formula-injection protection
- **Testing:** Jest + Supertest unit and API integration tests

## Requirements addressed
1. Express REST API for lead and service management.
2. Three-tier separation between presentation, business logic/API and persistence.
3. Persistent SQLite database instead of browser-only LocalStorage.
4. Automated Jest tests for lead scoring, normalization and API behaviour.
5. Server-side validation for lead and service data.
6. Safer CSV parsing with malformed-row handling, import limits and spreadsheet formula-injection protection on export.
7. Separate HTML, CSS, client JavaScript, routes, services, repositories and tests.
8. Existing CRM features retained: Kanban pipeline, lead scoring, follow-up queue, analytics, WhatsApp message preparation, service catalog and CSV import/export.

## Run locally
1. Install **Node.js 18 or newer**.
2. Extract the ZIP folder.
3. Open a terminal in the `leadlantern-final` folder.
4. Run:
   ```bash
   npm install
   npm test
   npm start
   ```
5. Open `http://localhost:3000`.

The SQLite database is created automatically at `data/leadlantern.sqlite` on first start.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health |
| GET | `/api/leads` | List leads |
| GET | `/api/leads/:id` | Read one lead |
| POST | `/api/leads` | Create lead |
| PUT | `/api/leads/:id` | Update lead |
| DELETE | `/api/leads/:id` | Delete lead |
| DELETE | `/api/leads` | Delete all leads |
| GET | `/api/services` | List services |
| POST | `/api/services` | Add service |
| PUT | `/api/services/:id` | Update service |
| DELETE | `/api/services/:id` | Delete service |
| GET | `/api/csv/export` | Download CSV |
| POST | `/api/csv/import` | Import CSV |

## Important notes
- The evaluator's report does not include the complete original SRS. This implementation directly addresses every improvement explicitly listed in the evaluation report.
- The project is a local academic demonstration. It does not claim production-grade user authentication, cloud hosting, backups or multi-user access; these were not listed as required in the supplied evaluation feedback.
- A high score cannot be guaranteed because the evaluator may use additional SRS criteria or a different runtime environment. Run the tests and demonstrate the API and database during evaluation.
